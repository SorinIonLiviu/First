/* Native accessible SVG bar chart — no chart library, CDNs or images. */
(function(M){
  'use strict';
  var NS='http://www.w3.org/2000/svg';
  function svg(tag,attrs){var e=document.createElementNS(NS,tag);Object.keys(attrs||{}).forEach(function(k){e.setAttribute(k,attrs[k]);});return e;}
  M.components.chart=function(state){
    var host=M.utils.elem('mu-chart');if(!host)return;host.replaceChildren();
    var data=state.chart||[];var title=M.utils.elem('mu-chart-heading');if(title)title.textContent=M.config.qlik.chartTitle||'Sales by category';
    var cnt=M.utils.elem('mu-chart-count');if(cnt)cnt.textContent=data.length+' categories';
    if(!data.length){host.appendChild(M.utils.make('p','mu-chart-empty',state.status==='error'?'Qlik data unavailable. Check configuration.':'Waiting for data…'));return;}
    var max=Math.max.apply(null,data.map(function(d){return d.value;}));if(max<=0)max=1;
    var bars=M.utils.make('div','mu-bars');
    data.forEach(function(d,i){
      var row=M.utils.make('div','mu-bar-row');
      var label=M.utils.make('span','mu-bar-label',d.label);label.title=d.label;
      var track=M.utils.make('button','mu-bar-track');track.type='button';track.setAttribute('aria-label','Select '+d.label+' category');track.title='Select '+d.label;
      var fill=M.utils.make('span','mu-bar-fill');fill.style.width=Math.max(0,Math.min(100,(d.value/max)*100))+'%';
      if(state.activeCategory && state.activeCategory!==d.label)fill.classList.add('mu-muted-bar');
      if(state.activeCategory===d.label)fill.classList.add('mu-selected-bar');
      track.appendChild(fill);track.addEventListener('click',function(){M.data.selectCategory(d.label);});
      var value=M.utils.make('span','mu-bar-value',M.utils.short(d.value));value.title=M.utils.money(d.value,d.formatted);
      row.appendChild(label);row.appendChild(track);row.appendChild(value);bars.appendChild(row);
    });
    host.appendChild(bars);
  };
})(window.Mashup);
