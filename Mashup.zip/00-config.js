/* JOB1 / JOB2 CONFIG — ONLY CHANGE THIS FILE FOR CONNECTING TO A REAL QLIK APP.
   Runtime mode: "demo" = fully standalone, "qlik" = existing Qlik authenticated session.
   The expressions below are EXAMPLES. Set actual fields/expressions for your app.
   Do not place credentials, bearer tokens or passwords in client-side files. */
window.MashupConfig = {
  mode: 'demo',
  appId: '',
  qlik: {
    filterField: 'Region',
    chartDimension: 'Category',
    kpiExpression: 'Sum(Sales)',
    chartExpression: 'Sum(Sales)',
    kpiTitle: 'Total sales',
    chartTitle: 'Sales by category',
    maxRows: 100
  },
  display: { currency: 'EUR', locale: 'en-GB', compact: false },
  debug: false
};
