(function(w){
  'use strict';
  var M=w.Mashup=w.Mashup||{};
  M.version='1.0.0';
  M.config=w.MashupConfig;
  M.components={}; M.features={};
  M.log=function(){ if(M.config.debug && w.console) console.log.apply(console,['[Mashup]'].concat(Array.prototype.slice.call(arguments))); };
  M.error=function(message,error){ console.error('[Mashup]',message,error||''); M.store && M.store.patch({status:'error', error:message}); };
})(window);
