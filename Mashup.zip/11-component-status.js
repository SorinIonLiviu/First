(function(M){
  'use strict';
  M.components.status=function(state){
    var badge=M.utils.elem('mu-runtime-badge'),engine=M.utils.elem('mu-engine-state'),detail=M.utils.elem('mu-engine-detail'),foot=M.utils.elem('mu-footer-status');
    if(!badge)return;badge.className='mu-runtime-badge '+(state.status==='connected'?'mu-runtime-live':state.status==='error'?'mu-runtime-error':'mu-runtime-demo');
    var text=state.status==='connected'?'Live Qlik':state.status==='connecting'?'Connecting to Qlik':state.status==='error'?'Connection error':'Demo data';
    badge.replaceChildren();badge.appendChild(M.utils.make('span','mu-status-dot'));badge.appendChild(document.createTextNode(text));
    if(engine)engine.textContent=state.status==='connected'?'Qlik associative engine':state.status==='error'?'Connection failed':state.status==='connecting'?'Qlik connection pending':'Demo engine';
    if(detail)detail.textContent=state.status==='error'?state.error:state.status==='connected'?'Live hypercubes update after selections.':state.status==='connecting'?'Authenticating and opening the app…':'Interactive synthetic data. No Qlik app configured.';
    if(foot)foot.textContent=state.status==='connected'?'Live data':state.status==='error'?'Action needed':'Offline-ready';
    var clear=M.utils.elem('mu-clear');if(clear)clear.disabled=state.status==='connecting'||state.status==='error'||!state.selections.length;
  };
})(window.Mashup);
