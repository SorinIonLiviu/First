(function(M){
  'use strict';
  M.components.kpi=function(state){
    var val=M.utils.elem('mu-kpi-value'),note=M.utils.elem('mu-kpi-note');
    if(val)val.textContent=M.utils.money(state.kpi.value,state.kpi.formatted);
    if(note)note.textContent=state.selections.length?state.selections.length+' active selection(s)':'All available data';
    var title=document.querySelector('.mu-kpi-label span');if(title)title.textContent=M.config.qlik.kpiTitle||'Total sales';
  };
})(window.Mashup);
