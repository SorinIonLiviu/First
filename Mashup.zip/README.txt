MASHUP — QLIK SENSE ENTERPRISE ON WINDOWS
Version: 1.0.0 | Offline-first initial deployment | Oct 2026

ADMIN: IMPORT ONCE
  1. In QMC > Extensions > Import, select the attached Mashup.zip.
  2. Import as a NEW extension named Mashup (Mashup.qext has type "mashup").
  3. Ensure the developer can UPDATE it in Dev Hub Mashup Editor.
  4. No server filesystems, npm, Node.js, CDN, separate web server or extra fonts needed.

  Launch URL:
    https://<your-host>[/<virtual-proxy>]/extensions/Mashup/Mashup.html

  Dev Hub URL:
    https://<your-host>[/<virtual-proxy>]/dev-hub/mashup-editor/#qext{Mashup}

DEVELOPER: WHAT WORKS IMMEDIATELY
  - The dashboard loads with clearly labeled synthetic demo data.
  - Changing Region updates the KPI and custom HTML/CSS bar chart.
  - Clicking a category bar filters the KPI; selection chips clear fields.
  - No JavaScript dependency is loaded from the public internet.

DEVELOPER: CONNECT TO A QLIK APP
  Edit 00-config.js in the Dev Hub Mashup Editor.
    mode: 'qlik',
    appId: '<the actual Qlik Sense app GUID>',
    qlik.filterField: '<actual field name>',
    qlik.chartDimension: '<actual field name>',
    qlik.kpiExpression: '<actual Qlik expression>',
    qlik.chartExpression: '<actual Qlik expression>'
  Save, then hard refresh (Ctrl+Shift+R).
  The user must have permission to open the app, access its data and use Qlik APIs.
  The browser connects through the existing Qlik session / virtual proxy.
  App fields, alternate states, Section Access, set analysis, variable definitions and
  performance are controlled by your Qlik app, not by these mock-data examples.

FILE ORGANIZATION
  Flat file layout is deliberate: the Qlik Mashup Editor is file/tab oriented.
  wbfolder.wbl includes all editable .html/.js/.css/.qext entries from day one.
  JS 00-12 = active. JS 13-24 = future feature slots (safe no-op comments).
  JS 80-84 = RESERVED vendor slots (EMPTY, contain no library code).
  CSS 00-06 = active styles including reserved theme/override files.
  To activate a feature/vendor later, add a script reference to Mashup.html.
  When editing through Dev Hub, avoid future add-file permissions entirely by
  replacing existing slot contents. More slots may be needed in a very large app.

ARCHITECTURE
  User interface = plain standards-based browser JavaScript, HTML and CSS.
  Qlik backend = built-in Capability API (RequireJS already shipped by Qlik).
  ONLY 04-qlik-adapter.js should call Qlik APIs.
  Components in 07-11 never import Qlik directly; they subscribe to normalized data.
  Native custom SVG/CSS charts keep the first demo fully self-contained.
  A later React/Vite build can target existing vendor/app placeholders if needed,
  but React, enigma.js and ECharts are NOT secretly embedded or installed here.

IMPORTANT DEPLOYMENT LIMITATIONS
  This package is verified syntactically and in stand-alone demo mode locally,
  but has NOT been tested against your real Qlik Enterprise release/proxy.
  Direct Dev Hub editing of the package still depends on your QMC rights/policies.
  Long/large minified libraries might be difficult to edit in Dev Hub; this is a
  main reason to avoid them in version 1.
  If Qlik browser Content Security Policy prevents some script loading,
  a Qlik admin may need to review policy (do NOT weaken policy automatically).
  No credentials, API tokens, sensitive business data or external telemetry are used.
  Existing Qlik authentication, authorization and Section Access still apply.

DEVELOPMENT NOTES
  - All assets must remain at the ZIP root for easiest Dev Hub management.
  - Dev Hub only shows files listed in wbfolder.wbl; do not delete or rename them.
  - A version query (?v=1) is present in Mashup.html; increment when changing files
    if browser caching prevents updates. A hard refresh usually suffices.
  - In live mode, fields should have manageable cardinality; first chart fetch
    uses maxRows (default 100), first filter fetch up to 200. Implement paging
    in 22-feature-data-cache.js for large datasets later.
  - Two jobs can use the exact same ZIP, with separate 00-config.js edits.
  - Treat any exported/downloaded data as sensitive corporate information.
