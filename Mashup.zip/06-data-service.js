(function(M){
  'use strict';
  function target(){return M.config.mode==='qlik'?M.qlik:M.mock;}
  async function call(method,arg){
    try {return await target()[method](arg);}catch(e){M.error('Action '+method+' failed: '+e.message,e);}
  }
  M.data={
    start:async function(){
      if(M.config.mode==='qlik'){
        M.store.patch({status:'connecting'});
        try {await M.qlik.connect();} catch(e){M.error('Cannot connect to Qlik: '+e.message,e);}
      }else M.mock.start();
    },
    selectRegion:function(v){return call('selectRegion',v);},
    selectCategory:function(v){return call('selectCategory',v);},
    clearAll:function(){return call('clearAll');},
    clearField:function(field){return call('clearField',field);},
    back:function(){return call('back');},
    forward:function(){return call('forward');}
  };
})(window.Mashup);
