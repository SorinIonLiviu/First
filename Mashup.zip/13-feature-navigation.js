/* Reserved for navigation, multi-page routes and user menus.
   Included in initial ZIP so it can be updated in Dev Hub later without adding files.
   To activate, add a script tag in Mashup.html after its dependencies. */
