(function(M){
  'use strict';
  M.utils={
    elem: function(id){return document.getElementById(id);},
    money: function(v, formatted){
      if(formatted && typeof formatted==='string' && formatted!=='-') return formatted;
      if(!Number.isFinite(v)) return '—';
      try { return new Intl.NumberFormat(M.config.display.locale,{style:'currency',currency:M.config.display.currency,maximumFractionDigits:0}).format(v); }
      catch(e){return String(Math.round(v));}
    },
    number: function(v){return Number.isFinite(v)?new Intl.NumberFormat(M.config.display.locale,{maximumFractionDigits:0}).format(v):'—';},
    short: function(v){return Number.isFinite(v)?new Intl.NumberFormat(M.config.display.locale,{notation:'compact',maximumFractionDigits:1}).format(v):'—';},
    make: function(tag,cls,text){var el=document.createElement(tag);if(cls)el.className=cls;if(text!==undefined)el.textContent=String(text);return el;},
    replace: function(parent,children){parent.replaceChildren.apply(parent,children);},
    qlikPrefix: function(){
      /* Handles both /extensions/... and /virtual-proxy/extensions/... URLs. */
      var pathname=window.location.pathname;
      var at=pathname.toLowerCase().indexOf('/extensions/');
      return at>=0?pathname.slice(0,at+1):'/';
    }
  };
})(window.Mashup);
