(function(M){
  'use strict';
  M.components.selections=function(state){
    var host=M.utils.elem('mu-selection-bar');host.replaceChildren();
    if(!state.selections.length){host.appendChild(M.utils.make('span','mu-no-selections','No active selections — showing all data'));return;}
    host.appendChild(M.utils.make('span','mu-selected-heading','SELECTED'));
    state.selections.forEach(function(s){
      var btn=M.utils.make('button','mu-selection-chip');btn.type='button';
      btn.textContent=s.field+': '+s.text+'  ×';btn.title='Clear selection in '+s.field;
      btn.addEventListener('click',function(){M.data.clearField(s.field);});host.appendChild(btn);
    });
  };
})(window.Mashup);
