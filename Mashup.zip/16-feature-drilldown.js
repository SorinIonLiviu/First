/* Reserved for drilldown, breadcrumbs and hierarchical navigation.
   Included in initial ZIP so it can be updated in Dev Hub later without adding files.
   To activate, add a script tag in Mashup.html after its dependencies. */
