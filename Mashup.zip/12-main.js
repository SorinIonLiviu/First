(function(M){
  'use strict';
  function start(){
    M.store.subscribe(function(state){
      ['filters','kpi','chart','selections','status'].forEach(function(name){M.components[name](state);});
    });
    M.utils.elem('mu-clear').addEventListener('click',function(){M.data.clearAll();});
    document.addEventListener('keydown',function(e){
      if((e.ctrlKey||e.metaKey)&&e.altKey && e.key==='Backspace'){e.preventDefault();M.data.clearAll();}
    });
    M.data.start();
  }
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',start);else start();
})(window.Mashup);
