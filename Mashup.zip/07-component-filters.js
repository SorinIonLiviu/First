(function(M){
  'use strict';
  M.components.filters=function(state){
    var root=M.utils.elem('mu-region-control');if(!root)return;
    root.replaceChildren();var label=M.utils.make('label','mu-control-label','REGION');label.htmlFor='mu-region-select';
    var sel=M.utils.make('select','mu-select');sel.id='mu-region-select';sel.setAttribute('aria-label','Select region');
    var all=M.utils.make('option','', 'All regions');all.value='All';sel.appendChild(all);
    state.filterOptions.forEach(function(o){var opt=M.utils.make('option','',o.label);opt.value=o.label;sel.appendChild(opt);});
    if(!Array.from(sel.options).some(function(o){return o.value===state.activeRegion;})){
      var extra=M.utils.make('option','',state.activeRegion);extra.value=state.activeRegion;sel.appendChild(extra);
    }
    sel.value=state.activeRegion||'All';sel.disabled=state.status==='connecting'||state.status==='error';
    sel.addEventListener('change',function(){M.data.selectRegion(sel.value);});
    root.appendChild(label);root.appendChild(sel);
  };
})(window.Mashup);
