(function(M){
  'use strict';
  var data={
    North:{Hardware:360000,Software:276000,Services:214000,Support:116000,Other:49000},
    South:{Hardware:253000,Software:196000,Services:241000,Support:98000,Other:63000},
    West:{Hardware:329000,Software:164000,Services:188000,Support:104000,Other:77000}
  };
  var region='All',category=null,history=[],redo=[];
  function refresh(){
    var regions=region==='All'?Object.keys(data):[region];
    var cats=Object.keys(data.North);
    var chart=cats.map(function(name){return {label:name,value:regions.reduce(function(t,r){return t+data[r][name];},0)};});
    var total=chart.reduce(function(sum,item){return sum+(!category||category===item.label?item.value:0);},0);
    var selections=[];
    if(region!=='All')selections.push({field:M.config.qlik.filterField,text:region,count:1});
    if(category)selections.push({field:M.config.qlik.chartDimension,text:category,count:1});
    M.store.patch({mode:'demo',status:'demo',error:'',kpi:{value:total,formatted:null},chart:chart,
      filterOptions:Object.keys(data).map(function(v){return {label:v,selected:v===region};}),
      activeRegion:region,activeCategory:category,selections:selections});
  }
  function snapshot(){history.push({region:region,category:category});redo=[];}
  M.mock={
    start:refresh,
    selectRegion:function(v){if(v!==region){snapshot();region=v;refresh();}},
    selectCategory:function(v){snapshot();category=category===v?null:v;refresh();},
    clearField:function(field){snapshot();if(field===M.config.qlik.filterField)region='All';if(field===M.config.qlik.chartDimension)category=null;refresh();},
    clearAll:function(){if(region!=='All'||category){snapshot();region='All';category=null;refresh();}},
    back:function(){if(history.length){redo.push({region:region,category:category});var s=history.pop();region=s.region;category=s.category;refresh();}},
    forward:function(){if(redo.length){history.push({region:region,category:category});var s=redo.pop();region=s.region;category=s.category;refresh();}}
  };
})(window.Mashup);
