(function(M){
  'use strict';
  var state={mode:M.config.mode,status:'loading',error:'',kpi:{value:0,formatted:null},chart:[],filterOptions:[],selections:[],activeRegion:'All',activeCategory:null,lastUpdated:null};
  var listeners=[];
  M.store={
    get:function(){return state;},
    patch:function(change){state=Object.assign({},state,change,{lastUpdated:new Date()});listeners.slice().forEach(function(fn){try{fn(state);}catch(e){console.error('[Mashup] view error',e);}});},
    subscribe:function(fn){listeners.push(fn);fn(state);return function(){listeners=listeners.filter(function(x){return x!==fn;});};}
  };
})(window.Mashup);
